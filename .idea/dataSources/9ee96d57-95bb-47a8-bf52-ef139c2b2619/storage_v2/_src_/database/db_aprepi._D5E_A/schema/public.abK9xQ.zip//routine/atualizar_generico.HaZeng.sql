create function atualizar_generico(nome_tabela character varying, chave character varying, valor character varying, campos json, forbidden_fields text[])
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
            table_fields text [];
            valid_fields text [];
            qtd_r int;
            c_name varchar;
            c_values varchar;

            keys text[];
            key text;

            update_str text;
        BEGIN

            SELECT cod_name, cod_value, qtd_registros into c_name, c_values, qtd_r from buscar_chave_valor(
                nome_tabela, chave, valor);

            SELECT array_agg(column_name::TEXT) INTO table_fields
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE table_name ilike nome_tabela and
                  not column_name = ANY(forbidden_fields);

            FOR key in SELECT json_object_keys(campos) LOOP
                IF key ILIKE ANY(table_fields) THEN
                    valid_fields := array_append(valid_fields, key);
                end if;
            end loop;

            FOREACH key in ARRAY valid_fields LOOP
                keys := array_append(keys, FORMAT('%1$s = ''%2$s''', key, campos->>key));
            end loop;

            update_str := FORMAT('UPDATE %1$s SET %2$s WHERE %3$s IN %4$s', nome_tabela, array_to_string(keys, ', '), c_name, c_values);
            raise notice '%', update_str;
            EXECUTE update_str;

            IF qtd_r = 1 THEN
                RETURN QUERY SELECT qtd_r || ' registro atualizado';
            ELSE
                RETURN QUERY SELECT qtd_r || ' registros atualizados';
            END IF;

            EXCEPTION
            WHEN CASE_NOT_FOUND OR ERROR_IN_ASSIGNMENT THEN
            RETURN QUERY SELECT unnest(ARRAY[SQLERRM]);
            WHEN unique_violation THEN
                RETURN QUERY SELECT unnest(
                    ARRAY[CONCAT('Campo já cadastrado! -> ', SQLERRM)]);
            WHEN others THEN
                RETURN QUERY SELECT unnest(
                    ARRAY[CONCAT('Erro durante o cadastro -> ', SQLERRM)]);

        END;
$$;

alter function atualizar_generico(varchar, varchar, varchar, json, text[]) owner to postgres;

