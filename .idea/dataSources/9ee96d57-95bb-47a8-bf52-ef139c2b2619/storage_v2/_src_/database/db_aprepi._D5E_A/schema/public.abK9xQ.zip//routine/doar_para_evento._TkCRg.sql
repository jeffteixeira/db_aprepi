create function doar_para_evento(nome_evento character varying, cpf_benfeitor character varying, valor_doado double precision)
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
        id_benfeitor int;
        id_evento int;
    BEGIN
        id_benfeitor := buscar_cod_benfeitor(cpf_benfeitor);
        id_evento := buscar_cod_evento(nome_evento);

        IF valor_doado <= 0 THEN
            RETURN QUERY SELECT 'O valor doado não pode ser menor ou igual a zero.';
            RETURN;
        end if;

        UPDATE evento SET arrecadacao = arrecadacao + valor_doado WHERE cod_evento=id_evento;
        RETURN QUERY SELECT 'Doação de valor realizada com sucesso!';
        RETURN;

        EXCEPTION
            WHEN CASE_NOT_FOUND OR ERROR_IN_ASSIGNMENT THEN
                RETURN QUERY SELECT SQLERRM;
                RETURN;
            WHEN others THEN
                RETURN QUERY SELECT CONCAT('Erro durante o cadastro -> ', SQLERRM);
                RETURN;
    END;
$$;

alter function doar_para_evento(varchar, varchar, double precision) owner to postgres;

