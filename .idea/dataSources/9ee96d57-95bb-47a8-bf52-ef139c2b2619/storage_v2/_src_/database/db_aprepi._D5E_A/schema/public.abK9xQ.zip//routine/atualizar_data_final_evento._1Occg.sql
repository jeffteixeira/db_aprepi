create function atualizar_data_final_evento(nome_evento character varying, data_fim date DEFAULT CURRENT_DATE)
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
        id_evento int;
    BEGIN
        id_evento := buscar_cod_evento(nome_evento);

        UPDATE evento SET dt_fim=data_fim WHERE cod_evento=id_evento;
        RETURN QUERY SELECT 'Data final do evento atualizada para ' || data_fim;
        RETURN;

        EXCEPTION
            WHEN CASE_NOT_FOUND OR ERROR_IN_ASSIGNMENT THEN
                RETURN QUERY SELECT SQLERRM;
                RETURN;
            WHEN others THEN
                RETURN QUERY SELECT CONCAT('Erro durante o cadastro -> ', SQLERRM);
                RETURN;
    END;
$$;

alter function atualizar_data_final_evento(varchar, date) owner to postgres;

