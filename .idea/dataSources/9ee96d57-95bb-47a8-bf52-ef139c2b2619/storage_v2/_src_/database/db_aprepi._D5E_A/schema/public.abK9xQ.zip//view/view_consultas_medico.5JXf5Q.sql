create view view_consultas_medico (cod_medico, nome_medico, nome_especialidade, dt_consulta, hora_consulta) as
SELECT m.cod_medico,
       m.nome AS nome_medico,
       e.nome AS nome_especialidade,
       c.dt_consulta,
       c.hora_consulta
FROM medico m
         JOIN medico_especialidade me ON m.cod_medico = me.cod_medico
         JOIN especialidade e ON me.cod_especialidade = e.cod_especialidade
         JOIN consulta c ON me.cod_medico_especialidade = c.cod_medico_especialidade;

alter table view_consultas_medico
    owner to postgres;

