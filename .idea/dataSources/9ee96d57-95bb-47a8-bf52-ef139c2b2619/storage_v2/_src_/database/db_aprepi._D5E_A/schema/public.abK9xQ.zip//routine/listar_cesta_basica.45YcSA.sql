create function listar_cesta_basica()
    returns TABLE(n text)
    security definer
    language plpgsql
as
$$
BEGIN
        RETURN QUERY select FORMAT('%1$s %2$s%3$s - %4$s und.',
                                    a.nome, a.grandeza, a.unidade_de_medida, cb.quantidade) as itens_cesta_basica
                            from cesta_basica cb inner join alimento a on a.cod_alimento = cb.cod_alimento;
        RETURN;

        EXCEPTION
            WHEN others THEN
                RETURN QUERY SELECT 'Erro durante q consulta -> ', SQLERRM;
    END;
$$;

alter function listar_cesta_basica() owner to postgres;

