create function montar_cesta_basica() returns json
    language plpgsql
as
$$
DECLARE
        row jsonb;
        cesta_basica_json json := '{}';
    BEGIN
        FOR row IN SELECT FORMAT('{"%1$s": %2$s}', x.nome, x.quantidade)::json from
        (SELECT a.nome, cb.quantidade from
          alimento a inner join cesta_basica cb on a.cod_alimento = cb.cod_alimento) x LOOP

                SELECT cesta_basica_json::jsonb || row INTO cesta_basica_json;
            end loop;

        RETURN cesta_basica_json;
    END;

$$;

alter function montar_cesta_basica() owner to postgres;

