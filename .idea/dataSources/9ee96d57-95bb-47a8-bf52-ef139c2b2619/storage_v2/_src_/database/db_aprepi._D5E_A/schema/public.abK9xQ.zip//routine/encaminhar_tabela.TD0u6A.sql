create function encaminhar_tabela(nome_tabela character varying, campos json)
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
        string varchar;
        lower_nome_tabela varchar := lower(nome_tabela);

    BEGIN
        IF lower_nome_tabela = 'doacao' or lower_nome_tabela = 'item_doacao' then
            IF campos->'cpf_benfeitor' IS NULL THEN
                RAISE ERROR_IN_ASSIGNMENT USING
                MESSAGE = 'Informe a chave [cpf_benfeitor] para usar a função "realizar_doacao" desta tabela';
            end if;
            string := (campos->'cpf_benfeitor')::varchar;
            SELECT campos::jsonb - 'cpf_benfeitor' INTO campos;
            RETURN QUERY SELECT realizar_doacao(string, campos);
            RETURN;

        ELSEIF lower_nome_tabela = 'recebimento' or lower_nome_tabela = 'item_recebimento' then
            IF campos->'cpf_socio' IS NULL THEN
                RAISE ERROR_IN_ASSIGNMENT USING
                MESSAGE = 'Informe a chave [cpf_socio] para usar a função "receber_doacao" desta tabela';
            end if;
            string := (campos->'cpf_socio')::varchar;
            SELECT campos::jsonb - 'cpf_socio' INTO campos;
            RETURN QUERY SELECT receber_doacao(string, campos);
            RETURN;

		ELSEIF lower_nome_tabela = 'consulta' then
            RETURN QUERY SELECT unnest(
                ARRAY[CONCAT('Use a função especifica para esta tabela.')]);
            RETURN;

		ELSEIF lower_nome_tabela = 'medico_especialidade' then
            RETURN QUERY SELECT unnest(
                ARRAY[CONCAT('Use a função especifica para esta tabela.')]);
            RETURN;

        ELSEIF lower_nome_tabela = 'evento' then
            RETURN QUERY SELECT unnest(
                ARRAY[CONCAT('Use a função especifica para esta tabela.')]);
            RETURN;

        ELSEIF lower_nome_tabela = 'voluntario_funcao' then
            RETURN QUERY SELECT unnest(
                ARRAY[CONCAT('Use a função especifica para esta tabela.')]);
            RETURN;

        ELSEIF lower_nome_tabela = 'benfeitor_evento' then
            RETURN QUERY SELECT unnest(
                ARRAY[CONCAT('Use a função especifica para esta tabela.')]);
            RETURN;

        ELSEIF lower_nome_tabela = 'cesta_basica' then
            IF campos->'item_cesta' IS NULL THEN
                RAISE ERROR_IN_ASSIGNMENT USING
                MESSAGE = 'Informe a chave [item_cesta] para usar a função "inserir_item_cesta" desta tabela';
            ELSEIF campos->'quantidade' IS NULL THEN
                RAISE ERROR_IN_ASSIGNMENT USING
                MESSAGE = 'Informe a chave [quantidade] para usar a função "inserir_item_cesta" desta tabela';
            end if;
            string := (campos->'item_cesta')::varchar;
            SELECT campos::jsonb - 'cpf_benfeitor' INTO campos;
            RETURN QUERY SELECT inserir_item_cesta_basica(trim('"' FROM string::text), (campos->>'quantidade')::int);
            RETURN;

        ELSE
            RETURN QUERY SELECT unnest(
                ARRAY[CONCAT('Tabela desconhecida.')]);
            RETURN;
		END IF;
    END;
$$;

alter function encaminhar_tabela(varchar, json) owner to postgres;

