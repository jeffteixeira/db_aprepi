create view view_doacoes_recebidas
            (cod_alimento, cod_recebimento, quantidade, unidade_de_medida, grandeza, nome, cod_socio, dt_recebimento) as
SELECT a.cod_alimento,
       ir.cod_recebimento,
       ir.quantidade,
       ir.unidade_de_medida,
       ir.grandeza,
       a.nome,
       r.cod_socio,
       r.dt_recebimento
FROM item_recebimento ir
         JOIN alimento a ON a.cod_alimento = ir.cod_alimento
         JOIN recebimento r ON r.cod_recebimento = ir.cod_recebimento;

alter table view_doacoes_recebidas
    owner to postgres;

