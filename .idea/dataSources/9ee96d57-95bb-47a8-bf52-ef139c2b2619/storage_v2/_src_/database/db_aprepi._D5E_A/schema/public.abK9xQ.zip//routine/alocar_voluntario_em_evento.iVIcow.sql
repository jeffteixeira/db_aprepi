create function alocar_voluntario_em_evento(nome_evento character varying, cpf_voluntario character varying, nome_funcao character varying)
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
        id_evento int;
        id_voluntario int;
        id_funcao int;
        nome_voluntario varchar;
        dt_fim_evento date;
    BEGIN
        id_evento := buscar_cod_evento(nome_evento);
        id_voluntario := buscar_cod_voluntario(cpf_voluntario);
        id_funcao = buscar_cod_funcao(nome_funcao);

        SELECT dt_fim INTO dt_fim_evento FROM evento WHERE cod_evento=id_evento;

        IF dt_fim_evento IS NOT NULL AND dt_fim_evento < current_date THEN
            RETURN QUERY SELECT 'Não é possivel alocar um voluntário em um evento já encerrado.';
            RETURN;
        end if;

        INSERT INTO voluntario_funcao(cod_voluntario, cod_evento, cod_funcao) VALUES (id_voluntario, id_evento, id_funcao);

        SELECT nome into nome_voluntario FROM voluntario WHERE cod_voluntario=id_voluntario;
        RETURN QUERY SELECT FORMAT('%1$s alocado na função %2$s do evento %3$s com sucesso.', nome_voluntario, nome_funcao, nome_evento);

        EXCEPTION
        WHEN ERROR_IN_ASSIGNMENT OR CASE_NOT_FOUND THEN
            RETURN QUERY SELECT SQLERRM;
        WHEN others THEN
            RETURN QUERY SELECT CONCAT('Erro durante o cadastro da alocação -> ', SQLERRM);
    END
$$;

alter function alocar_voluntario_em_evento(varchar, varchar, varchar) owner to postgres;

