create function cadastrar_socio(campos json)
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
            required_fields text [];
            nullable_fields text [];
            campo text;
            erros text[]:= '{"OS SEGUINTES ERROS FORAM ENCONTRADOS"}';
            campos_validos boolean := true;
            keys_str text;
            keys text[];
            values_str text;
            values text[];
            insert_str text;
        BEGIN
            SELECT array_agg(column_name::TEXT) INTO required_fields
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE table_name ilike 'socio' and is_nullable ilike 'NO' and
                  column_name not in ('dt_falecimento', 'cod_socio');

            FOREACH campo IN ARRAY required_fields LOOP
                IF (campos->campo) IS NULL THEN
                    raise notice '[%] nao pode ser vazio', campo;
                    erros := array_append(erros, concat('[', campo, '] não pode ser vazio'));
                    campos_validos := false;
                ELSE
                    keys := array_append(keys, campo);
                    values := array_append(values, (campos->campo)::text);
                end if;
            END LOOP;

            IF NOT campos_validos THEN
                raise notice 'estou aqui==================';
                RETURN QUERY SELECT nome FROM unnest(erros) as nome;
                RETURN;
            end if;

            SELECT array_agg(column_name::TEXT) INTO nullable_fields
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE table_name ilike 'socio' and is_nullable ilike 'YES' and
                  column_name not in ('dt_falecimento', 'cod_socio');

            FOREACH campo IN ARRAY nullable_fields LOOP
                IF (campos->campo) IS NULL THEN
                    SELECT campos::jsonb || FORMAT('{"%s": %s}', campo, 'null')::jsonb INTO campos;
                ELSE
                    keys := array_append(keys, campo);
                    values := array_append(values, 'null');
                end if;
            END LOOP;

--             select string_agg(key, ', '), string_agg(value::text, ', ') INTO keys_str, values_str
--             from json_each(campos);

            keys_str := array_to_string(keys, ', ');
            values_str := array_to_string(values, ', ');

            insert_str := REGEXP_REPLACE(FORMAT('INSERT INTO socio(%s) VALUES (%s)', keys_str, values_str), '"', '''', 'g');
            raise notice '%', insert_str;
            EXECUTE insert_str;

            RETURN QUERY SELECT unnest(ARRAY[CONCAT('Novo sócio cadastrado com sucesso!')]);

            EXCEPTION
            WHEN others THEN
                RETURN QUERY SELECT unnest(
                    ARRAY[CONCAT('Erro durante o cadastro: ', SQLERRM)]);
        END;
$$;

alter function cadastrar_socio(json) owner to postgres;

