create function criar_evento(nome_evento character varying, nome_tipo_evento character varying, valor_arrecacao double precision DEFAULT 0, valor_custo double precision DEFAULT 0, data_inicio date DEFAULT CURRENT_DATE, data_fim date DEFAULT NULL::date)
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
        id_tipo_evento int := buscar_cod_tipo_evento(nome_tipo_evento);
    BEGIN
        INSERT INTO evento(cod_tipo_evento, arrecadacao, custo, nome, dt_inicio, dt_fim) values
        (id_tipo_evento, valor_arrecacao, valor_custo, nome_evento, data_inicio, data_fim);

        RETURN QUERY SELECT 'Novo evento cadastrado com sucesso!';
        RETURN;

        EXCEPTION
            WHEN CASE_NOT_FOUND OR ERROR_IN_ASSIGNMENT THEN
                RETURN QUERY SELECT SQLERRM;
                RETURN;
            WHEN others THEN
                RETURN QUERY SELECT CONCAT('Erro durante o cadastro -> ', SQLERRM);
                RETURN;
    END;
$$;

alter function criar_evento(varchar, varchar, double precision, double precision, date, date) owner to postgres;

