create function fc_trigger_benfeitor() returns trigger
    language plpgsql
as
$$
BEGIN
        select validador_cpf(NEW.cpf) into NEW.cpf;
        RETURN NEW;
    END;
$$;

alter function fc_trigger_benfeitor() owner to postgres;

