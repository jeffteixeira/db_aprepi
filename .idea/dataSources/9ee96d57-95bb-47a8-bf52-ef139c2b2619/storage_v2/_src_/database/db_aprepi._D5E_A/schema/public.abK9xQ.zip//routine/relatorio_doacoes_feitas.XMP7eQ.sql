create function relatorio_doacoes_feitas(campos json DEFAULT '{}'::json)
    returns TABLE(relatorio text)
    language plpgsql
as
$$
DECLARE
        id_benfeitor int;
    BEGIN
        IF campos->'cpf_benfeitor' IS NOT NULL THEN
            id_benfeitor := buscar_cod_benfeitor(campos->>'cpf_benfeitor');
            RETURN QUERY SELECT 'FILTRO POR: BENFEITOR';
            RETURN QUERY
                SELECT FORMAT('%1$s -> %2$s %3$s', nome, (sum(grandeza) * sum(quantidade)), unidade_de_medida) FROM
            view_doacoes_feitas WHERE cod_benfeitor = id_benfeitor GROUP BY nome, unidade_de_medida;

        ELSEIF campos->'dt_inicial' IS NOT NULL and campos->'dt_final' IS NULL THEN
            RETURN QUERY SELECT FORMAT('FILTRO POR: DATA(%1$s até %2$s)', (campos->>'dt_inicial')::date, current_date);

            RETURN QUERY SELECT FORMAT('%1$s -> %2$s %3$s', x.nome, x.quantidade_total, x.unidade_de_medida) FROM
            (SELECT nome, (sum(grandeza) * sum(quantidade)) as quantidade_total, unidade_de_medida FROM
            view_doacoes_feitas WHERE dt_doacao between (campos->>'dt_inicial')::date and current_date
            GROUP BY nome, unidade_de_medida order by quantidade_total) x;

        ELSEIF campos->'dt_inicial' IS NOT NULL and campos->'dt_final' IS NOT NULL THEN
            RETURN QUERY SELECT FORMAT('FILTRO POR: DATA(%1$s até %2$s)', (campos->>'dt_inicial')::date,(campos->>'dt_final')::date);

            RETURN QUERY SELECT FORMAT('%1$s -> %2$s %3$s', x.nome, x.quantidade_total, x.unidade_de_medida) FROM
            (SELECT nome, (sum(grandeza) * sum(quantidade)) as quantidade_total, unidade_de_medida FROM
            view_doacoes_feitas WHERE dt_doacao between (campos->>'dt_inicial')::date and (campos->>'dt_final')::date
            GROUP BY nome, unidade_de_medida order by quantidade_total) x;

        ELSE
            RETURN QUERY SELECT 'FILTRO POR: GERAL';
            RETURN QUERY SELECT FORMAT('%1$s -> %2$s %3$s', x.nome, x.quantidade_total, x.unidade_de_medida) FROM
            (SELECT nome, (sum(grandeza) * sum(quantidade)) as quantidade_total, unidade_de_medida FROM
            view_doacoes_feitas GROUP BY nome, unidade_de_medida order by quantidade_total) x;
        END IF;

        RETURN;

        EXCEPTION
            WHEN ERROR_IN_ASSIGNMENT OR CASE_NOT_FOUND THEN
                RETURN QUERY SELECT SQLERRM;
            WHEN others THEN
                RETURN QUERY SELECT 'Erro durante a consulta -> ' || SQLERRM;
    END;

$$;

alter function relatorio_doacoes_feitas(json) owner to postgres;

