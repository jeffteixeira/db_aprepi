create function listar_alimentos()
    returns TABLE(n text)
    security definer
    language plpgsql
as
$$
BEGIN
        RETURN QUERY select FORMAT('%s %s%s -> %s und. disponíveis', nome, grandeza, unidade_de_medida, quantidade, descricao) from alimento;
        RETURN;
    END;
$$;

alter function listar_alimentos() owner to postgres;

