create function fc_trigger_alocacao_evento() returns trigger
    language plpgsql
as
$$
DECLARE
        voluntario_ja_alocado boolean;
    BEGIN
        SELECT EXISTS (SELECT FROM voluntario_funcao WHERE cod_evento=NEW.cod_evento AND cod_voluntario=NEW.cod_voluntario)
        INTO voluntario_ja_alocado;
        IF voluntario_ja_alocado THEN
            raise ERROR_IN_ASSIGNMENT using
            message='Voluntario já alocado no evento, primeiro remova o voluntario do evento para alocar ele em uma nova função.';
        end if;
        RETURN NEW;
    END;
$$;

alter function fc_trigger_alocacao_evento() owner to postgres;

