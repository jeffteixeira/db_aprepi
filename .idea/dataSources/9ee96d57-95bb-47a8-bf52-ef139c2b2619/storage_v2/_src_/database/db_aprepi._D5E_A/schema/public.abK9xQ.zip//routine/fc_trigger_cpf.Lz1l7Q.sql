create function fc_trigger_cpf() returns trigger
    language plpgsql
as
$$
BEGIN
        select validador_cpf(NEW.cpf) into NEW.cpf;
        RETURN NEW;
    END;
$$;

alter function fc_trigger_cpf() owner to postgres;

