create view view_doacoes_feitas
            (cod_alimento, cod_doacao, quantidade, unidade_de_medida, grandeza, nome, cod_benfeitor, dt_doacao) as
SELECT a.cod_alimento,
       id.cod_doacao,
       id.quantidade,
       id.unidade_de_medida,
       id.grandeza,
       a.nome,
       d.cod_benfeitor,
       d.dt_doacao
FROM item_doacao id
         JOIN alimento a ON a.cod_alimento = id.cod_alimento
         JOIN doacao d ON d.cod_doacao = id.cod_doacao;

alter table view_doacoes_feitas
    owner to postgres;

