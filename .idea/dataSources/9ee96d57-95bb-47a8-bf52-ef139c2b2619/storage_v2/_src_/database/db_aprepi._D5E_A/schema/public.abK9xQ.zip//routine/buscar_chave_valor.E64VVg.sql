create function buscar_chave_valor(nome_tabela character varying, chave character varying, valor character varying)
    returns TABLE(cod_name character varying, cod_value character varying, qtd_registros integer)
    language plpgsql
as
$$
declare
        c_name varchar;
        c_values varchar[];
    BEGIN
        SELECT c.column_name INTO c_name
        FROM information_schema.table_constraints tc
        JOIN information_schema.constraint_column_usage AS ccu USING (constraint_schema, constraint_name)
        JOIN information_schema.columns AS c ON c.table_schema = tc.constraint_schema
          AND tc.table_name = c.table_name AND ccu.column_name = c.column_name
        WHERE constraint_type = 'PRIMARY KEY' and tc.table_name ilike nome_tabela;

        EXECUTE FORMAT('SELECT array_agg(%1$s::text) FROM %2$s WHERE %3$s = ''%4$s''', c_name, nome_tabela, chave, valor) INTO c_values;

        IF c_name IS NULL THEN
            RAISE CASE_NOT_FOUND USING MESSAGE = 'Tabela' || nome_tabela || 'Não encontrada.';
        ELSEIF c_values IS NULL THEN
            RAISE CASE_NOT_FOUND USING MESSAGE = 'Nenhum registro encontrado para a chave e valor procurados.';
        end if;

        RETURN QUERY SELECT c_name, FORMAT('(%1$s)', array_to_string(c_values, ','))::varchar, array_length(c_values, 1);
        RETURN;
    END;
$$;

alter function buscar_chave_valor(varchar, varchar, varchar) owner to postgres;

