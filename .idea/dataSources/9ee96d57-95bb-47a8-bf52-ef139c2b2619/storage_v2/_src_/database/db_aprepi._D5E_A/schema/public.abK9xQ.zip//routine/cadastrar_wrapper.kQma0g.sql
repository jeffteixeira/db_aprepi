create function cadastrar_wrapper(nome_tabela character varying, campos json)
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
            forbidden_fields_by_table json := '{
              "socio": ["dt_falecimento", "cod_socio"],
              "medico": ["cod_medico", "dt_saida"]
            }';
            forbidden_fields text [];
            fbn_field json;
            table_exists boolean;
        BEGIN
            SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name=nome_tabela) INTO table_exists;

            IF nome_tabela ILIKE ANY(ARRAY ['doacao', 'consulta']) THEN
                RETURN QUERY SELECT unnest(ARRAY[CONCAT('Não pode cadastrar diretamente em ', nome_tabela, '!')]);
                RETURN;
            ELSEIF NOT table_exists THEN
                raise notice 'ei tabela nao existe';
                RETURN QUERY SELECT unnest(
                    ARRAY[CONCAT('A tabela ', nome_tabela, ' não foi encontrada, verifique o nome e tente novamente.')]);
                    RETURN;
            ELSEIF (forbidden_fields_by_table->nome_tabela) IS NULL THEN
                RETURN QUERY SELECT unnest(
                    ARRAY[CONCAT('A tabela ', nome_tabela, ' não foi cadastrada corretamente. Contate o administrador..')]);
                    RETURN;
            END IF;

            FOR fbn_field IN
                SELECT json_array_elements FROM json_array_elements(forbidden_fields_by_table->nome_tabela) LOOP
                forbidden_fields := array_append(forbidden_fields, REGEXP_REPLACE(fbn_field::text, '"', '', 'g'));
            END LOOP;

            raise notice '%', forbidden_fields;

            RETURN QUERY  SELECT cadastrar_generico(nome_tabela, campos, forbidden_fields);

            EXCEPTION
            WHEN others THEN
                RETURN QUERY SELECT unnest(
                    ARRAY[CONCAT('Erro durante o cadastro: ', SQLERRM)]);
        END;
$$;

alter function cadastrar_wrapper(varchar, json) owner to postgres;

