create function fc_trigger_cesta_basica() returns trigger
    language plpgsql
as
$$
BEGIN

        IF NEW.quantidade <= 0 THEN
            raise ERROR_IN_ASSIGNMENT using
            message='Quantidade não pode ser negativa nem zero, insira uma quantidade maior que zero';
        end if;

        RETURN NEW;
    END;
$$;

alter function fc_trigger_cesta_basica() owner to postgres;

