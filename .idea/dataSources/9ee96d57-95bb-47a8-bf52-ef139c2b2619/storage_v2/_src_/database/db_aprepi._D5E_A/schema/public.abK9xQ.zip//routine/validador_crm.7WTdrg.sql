create function validador_crm(crm character varying) returns character varying
    language plpgsql
as
$$
DECLARE

        estados text[] := '{"AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", ' ||
                          '"GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", ' ||
                          '"PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"}';
        sanitize_crm varchar := UPPER(REGEXP_REPLACE(crm, '([^0-9/\\a-zA-Z])+', '', 'g'));
        length_crm int := length(sanitize_crm);
    BEGIN

        IF not SUBSTRING(sanitize_crm, length_crm -1, length_crm) ilike any(estados) THEN
            RAISE ERROR_IN_ASSIGNMENT USING
            MESSAGE = 'Informe um UF valido para o CRM no seguinte formato 000000/UF';

        ELSEIF not SUBSTRING(sanitize_crm, length_crm -2, 1) ilike '/' THEN
            raise notice 'substr: %', SUBSTRING(sanitize_crm, length_crm -3, 1);
            RAISE ERROR_IN_ASSIGNMENT USING
            MESSAGE = 'Informe um CRM no seguinte formato 000000/UF';

        ELSEIF not SUBSTRING(sanitize_crm, 1, length_crm - 3) ~ '^[0-9\.]+$' THEN
            RAISE ERROR_IN_ASSIGNMENT USING
            MESSAGE = 'Informe um CRM no seguinte formato 000000/UF';
        end if;

        RETURN sanitize_crm;
    END
$$;

alter function validador_crm(varchar) owner to postgres;

