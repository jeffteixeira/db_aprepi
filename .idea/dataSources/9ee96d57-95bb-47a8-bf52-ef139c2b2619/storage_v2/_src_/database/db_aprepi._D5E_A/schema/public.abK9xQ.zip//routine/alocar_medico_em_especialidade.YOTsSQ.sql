create function alocar_medico_em_especialidade(nome_medico character varying, nome_especialidade character varying)
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
        id_medico int;
        id_especialidade int;
    BEGIN
        id_medico := buscar_cod_medico(nome_medico);
        id_especialidade := buscar_cod_especialidade(nome_especialidade);

        INSERT INTO medico_especialidade(cod_especialidade, cod_medico) VALUES (id_especialidade, id_medico);

        RETURN QUERY SELECT FORMAT('%1$s alocado na especialidade %2$s com sucesso.', nome_medico, nome_especialidade);

        EXCEPTION
        WHEN ERROR_IN_ASSIGNMENT OR CASE_NOT_FOUND THEN
            RETURN QUERY SELECT SQLERRM;
        WHEN others THEN
            RETURN QUERY SELECT CONCAT('Erro durante a execução -> ', SQLERRM);
    END;
$$;

alter function alocar_medico_em_especialidade(varchar, varchar) owner to postgres;

