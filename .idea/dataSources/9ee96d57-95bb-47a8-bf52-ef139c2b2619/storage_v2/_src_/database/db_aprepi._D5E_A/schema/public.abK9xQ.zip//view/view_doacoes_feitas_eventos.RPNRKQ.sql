create view view_doacoes_feitas_eventos(cod_evento, cod_benfeitor, valor_doado, nome, dt_inicio, dt_fim) as
SELECT be.cod_evento,
       be.cod_benfeitor,
       COALESCE(be.valor_doado, 0::double precision) AS valor_doado,
       e.nome,
       e.dt_inicio,
       e.dt_fim
FROM benfeitor_evento be
         RIGHT JOIN evento e ON e.cod_evento = be.cod_evento;

alter table view_doacoes_feitas_eventos
    owner to postgres;

