create function informar_falecimento_socio(cpf character varying)
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
        id int;
    BEGIN
        id := buscar_cod_socio(cpf);
        UPDATE socio SET dt_falecimento = current_date WHERE cod_socio = id;
        RETURN QUERY SELECT 'Operação realizada com sucesso.';

        EXCEPTION
            WHEN others THEN
                RETURN QUERY SELECT unnest(ARRAY[CONCAT('Erro durante a execução -> ', SQLERRM)]);
    END;
$$;

alter function informar_falecimento_socio(varchar) owner to postgres;

