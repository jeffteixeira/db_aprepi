create function adicionar_custo_evento(nome_evento character varying, valor_custo double precision)
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
        id_evento int;
    BEGIN
        id_evento := buscar_cod_evento(nome_evento);

        IF valor_custo <= 0 THEN
            RETURN QUERY SELECT 'O valor do custo não pode ser menor ou igual a zero.';
            RETURN;
        end if;

        UPDATE evento SET custo=custo + valor_custo WHERE cod_evento=id_evento;
        RETURN QUERY SELECT 'Custo do evento atualizado com sucesso!';
        RETURN;

        EXCEPTION
            WHEN CASE_NOT_FOUND OR ERROR_IN_ASSIGNMENT THEN
                RETURN QUERY SELECT SQLERRM;
                RETURN;
            WHEN others THEN
                RETURN QUERY SELECT CONCAT('Erro durante o cadastro -> ', SQLERRM);
                RETURN;
    END;
$$;

alter function adicionar_custo_evento(varchar, double precision) owner to postgres;

