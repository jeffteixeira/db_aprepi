create function cadastrar(nome_tabela character varying, campos json)
    returns TABLE(n text)
    security definer
    SET search_path = public
    language plpgsql
as
$$
DECLARE
            forbidden_fields_by_table json := '{"SOCIO": ["dt_falecimento", "cod_socio"],' ||
                                              '"BENFEITOR": ["cod_benfeitor"],' ||
                                              '"MEDICO": ["cod_medico"],' ||
                                              '"ESPECIALIDADE": ["cod_especialidade"],' ||
                                              '"VOLUNTARIO": ["cod_voluntario"],' ||
                                              '"FUNCAO": ["cod_funcao"],' ||
                                              '"ALIMENTO": ["cod_alimento"]}';
            forbidden_tables varchar[] := '{"consulta", ' ||
                                          '"recebimento", ' ||
                                          '"doacao", ' ||
                                          '"item_recebimento", ' ||
                                          '"item_doacao", ' ||
                                          '"medico_especialidade", ' ||
                                          '"voluntario_funcao", ' ||
                                          '"evento", ' ||
                                          '"cesta_basica", ' ||
                                          '"benfeitor_evento"}';
            forbidden_fields text [];
            fbn_field json;
            table_exists boolean;
            nome_tabela_upper varchar := upper(nome_tabela);
        BEGIN
            SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name ilike nome_tabela) INTO table_exists;

            IF nome_tabela ILIKE ANY(forbidden_tables) THEN
                RETURN QUERY SELECT encaminhar_tabela(nome_tabela, campos);
                RETURN;
            ELSEIF NOT table_exists THEN

                RETURN QUERY SELECT unnest(
                    ARRAY[CONCAT('A tabela ', nome_tabela, ' não foi encontrada, verifique o nome e tente novamente.')]);
                    RETURN;
            ELSEIF (forbidden_fields_by_table->nome_tabela_upper) IS NULL THEN
                RETURN QUERY SELECT unnest(
                    ARRAY[CONCAT('A tabela ', nome_tabela, ' não foi cadastrada corretamente. Contate o administrador.')]);
                    RETURN;
            END IF;

            FOR fbn_field IN
                SELECT json_array_elements FROM json_array_elements(forbidden_fields_by_table->nome_tabela_upper) LOOP
                forbidden_fields := array_append(forbidden_fields, REGEXP_REPLACE(fbn_field::text, '"', '', 'g'));
            END LOOP;

            raise notice '%', forbidden_fields;

            RETURN QUERY SELECT cadastrar_generico(nome_tabela_upper, campos, forbidden_fields);
            RETURN;

            EXCEPTION
            WHEN ERROR_IN_ASSIGNMENT THEN
                RETURN QUERY SELECT SQLERRM;
            WHEN others THEN
                RETURN QUERY SELECT unnest(
                    ARRAY[CONCAT('Erro durante o cadastro: ', SQLERRM)]);
        END;
$$;

alter function cadastrar(varchar, json) owner to postgres;

