create function buscar_cod_tipo_evento(nome_tipo_evento character varying) returns integer
    language plpgsql
as
$$
DECLARE
        id int;
        total_rows int;
    BEGIN
        SELECT cod_tipo_evento INTO id FROM TIPO_EVENTO WHERE nome ilike nome_tipo_evento;
        SELECT count(cod_tipo_evento) INTO total_rows FROM TIPO_EVENTO WHERE nome ilike nome_tipo_evento;

        IF id is NULL OR total_rows = 0 THEN
            RAISE CASE_NOT_FOUND USING MESSAGE = 'Nenhum tipo de evento encontrado com o nome ' || nome_tipo_evento;
        ELSEIF total_rows > 1 THEN
            RAISE ERROR_IN_ASSIGNMENT USING MESSAGE = 'Mais de um tipo de evento encontrado com o nome ' || nome_tipo_evento
                                                    || '. Renomeie os tipos de evento que tem nomes iguais para nomes diferentes e tente novamente.';
        end if;
        RETURN id;
    END;
$$;

alter function buscar_cod_tipo_evento(varchar) owner to postgres;

