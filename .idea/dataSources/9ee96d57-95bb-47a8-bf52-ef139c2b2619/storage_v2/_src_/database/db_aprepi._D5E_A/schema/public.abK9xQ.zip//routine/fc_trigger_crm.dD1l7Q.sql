create function fc_trigger_crm() returns trigger
    language plpgsql
as
$$
BEGIN
        select validador_crm(NEW.crm) into NEW.crm;
        RETURN NEW;
    END;
$$;

alter function fc_trigger_crm() owner to postgres;

