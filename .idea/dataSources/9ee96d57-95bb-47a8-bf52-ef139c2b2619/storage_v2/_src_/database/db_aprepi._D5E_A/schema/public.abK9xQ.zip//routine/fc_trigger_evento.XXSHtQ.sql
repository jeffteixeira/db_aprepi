create function fc_trigger_evento() returns trigger
    language plpgsql
as
$$
BEGIN
        IF NEW.custo < 0 THEN
            raise ERROR_IN_ASSIGNMENT using
            message='O custo não pode ser negativo, insira uma quantidade maior ou igual a zero';
        ELSEIF NEW.arrecadacao < 0 THEN
            raise ERROR_IN_ASSIGNMENT using
            message='A arrecadação não pode ser negativa, insira uma quantidade maior ou igual a zero';
        ELSEIF (NEW.arrecadacao != OLD.arrecadacao OR NEW.custo != OLD.custo) AND
               NEW.dt_fim IS NOT NULL AND NEW.dt_fim < current_date THEN
            raise ERROR_IN_ASSIGNMENT using
            message='Eventos finalizados não podem ter custos ou arrecadações modificados';
        end if;

        NEW.nome := btrim(NEW.nome);

        RETURN NEW;
    END;
$$;

alter function fc_trigger_evento() owner to postgres;

