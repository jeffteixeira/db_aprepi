create function buscar_cod_especialidade(nome_especialidade character varying) returns integer
    language plpgsql
as
$$
DECLARE
        id int;
        total_rows int;
    BEGIN
        SELECT cod_especialidade INTO id FROM ESPECIALIDADE WHERE nome ilike nome_especialidade;
        SELECT count(cod_especialidade) INTO total_rows FROM ESPECIALIDADE WHERE nome ilike nome_especialidade;

        IF id is NULL OR total_rows = 0 THEN
            RAISE CASE_NOT_FOUND USING MESSAGE = 'Nenhuma especialidade encontrado com o nome ' || nome_especialidade;
        ELSEIF total_rows > 1 THEN
            RAISE ERROR_IN_ASSIGNMENT USING MESSAGE = 'Mais de uma especialidade encontrada com o nome ' || nome_especialidade
                                                    || '. Renomeie as especialidades que tem nomes iguais para nomes diferentes e tente novamente.';
        end if;
        RETURN id;
    END;
$$;

alter function buscar_cod_especialidade(varchar) owner to postgres;

