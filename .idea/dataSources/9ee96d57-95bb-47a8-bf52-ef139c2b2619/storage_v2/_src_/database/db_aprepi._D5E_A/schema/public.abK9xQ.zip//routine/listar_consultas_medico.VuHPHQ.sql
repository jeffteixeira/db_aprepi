create function listar_consultas_medico(_nome_medico character varying, data_consulta date DEFAULT CURRENT_DATE)
    returns TABLE(consultas text)
    language plpgsql
as
$$
DECLARE
        id_medico int;
        dias text[] := '{"Seg", "Ter", "Qua", "Qui", "Sex", "Sab", "Dom"}';
        meses text[] := '{"jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"}';
        dia_semana text;
        dia_mes text;
        mes text;
        ano text;
        data_formatada text;
    BEGIN
        id_medico := buscar_cod_medico(_nome_medico);
        dia_semana := dias[extract(isodow from data_consulta)];
        dia_mes := extract(day from data_consulta);
        mes := meses[extract(month from data_consulta)];
        ano := extract(year from data_consulta);

        data_formatada := FORMAT('%1$s, %2$s de %3$s de %4$s', dia_semana, dia_mes, mes, ano);

        RETURN QUERY SELECT 'Consultas para o médico ' || _nome_medico || ' - ' || data_formatada;

        IF exists(SELECT FROM view_consultas_medico
                WHERE cod_medico=id_medico AND dt_consulta=data_consulta order by hora_consulta) THEN

            RETURN QUERY SELECT FORMAT('Como %1$s às %2$s ', nome_especialidade, hora_consulta) FROM view_consultas_medico
            WHERE cod_medico=id_medico AND dt_consulta=data_consulta order by hora_consulta;
        ELSE
            RETURN QUERY SELECT 'Nenhuma consulta agendada para esta data';
        END IF;

        RETURN;
    END
$$;

alter function listar_consultas_medico(varchar, date) owner to postgres;

