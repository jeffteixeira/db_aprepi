create function fc_trigger_consulta() returns trigger
    language plpgsql
as
$$
DECLARE
        proxima_hora time;
        id_medico int;
        especialidades_medico int[];
        hora_anterior time;
        intervalo_minimo interval := '01:00';
        intervalo_consulta interval;
        horario_valido boolean;
    BEGIN

        IF extract(isodow from NEW.dt_consulta) = ANY('{7,6}'::int[]) THEN
            raise ERROR_IN_ASSIGNMENT using
                message='As consultas so podem ser marcadas de Segunda a Sexta';
        ELSEIF NOT (NEW.hora_consulta between time '8:00' and time '12:00' or
               NEW.hora_consulta between time '14:00' and time '18:00') THEN
            raise ERROR_IN_ASSIGNMENT using
                message='As consultas so podem ser marcadas pela manhã entre 8:00h e 12:00h ou pela tarde entre 14:00h e 18:00h';
        end if;

        SELECT cod_medico into id_medico from medico_especialidade WHERE cod_medico_especialidade=NEW.cod_medico_especialidade;
        SELECT array_agg(cod_medico_especialidade) INTO especialidades_medico FROM medico_especialidade WHERE cod_medico=id_medico;

--         SELECT hora_consulta INTO hora_anterior FROM consulta
--         WHERE dt_consulta=NEW.dt_consulta AND cod_medico_especialidade=NEW.cod_medico_especialidade
--         AND hora_consulta < NEW.hora_consulta
--         ORDER BY hora_consulta DESC LIMIT 1;
--
--         SELECT hora_consulta INTO proxima_hora FROM consulta
--         WHERE dt_consulta=NEW.dt_consulta AND cod_medico_especialidade=NEW.cod_medico_especialidade
--         AND hora_consulta > NEW.hora_consulta
--         ORDER BY hora_consulta LIMIT 1;

        SELECT hora_consulta INTO hora_anterior FROM consulta
        WHERE dt_consulta=NEW.dt_consulta AND cod_medico_especialidade = ANY (especialidades_medico)
        AND hora_consulta <= NEW.hora_consulta
        ORDER BY hora_consulta DESC LIMIT 1;

        SELECT hora_consulta INTO proxima_hora FROM consulta
        WHERE dt_consulta=NEW.dt_consulta AND cod_medico_especialidade = ANY (especialidades_medico)
        AND hora_consulta >= NEW.hora_consulta
        ORDER BY hora_consulta LIMIT 1;

        raise notice 'proxima hora: %', proxima_hora;
        raise notice 'hora anterior: %', hora_anterior;

        IF proxima_hora IS NULL AND hora_anterior IS NOT NULL THEN
            intervalo_consulta := (NEW.hora_consulta - hora_anterior);
            SELECT intervalo_consulta >= intervalo_minimo INTO horario_valido;
            IF not horario_valido THEN
                raise ERROR_IN_ASSIGNMENT using
                message=FORMAT('O intervalo minimo entre duas consultas é de %1$s. ' ||
                               'A ultima consulta desse medico está marcada para %2$s h.', intervalo_minimo, hora_anterior);
            end if;

        ELSEIF proxima_hora IS NOT NULL AND hora_anterior IS NOT NULL THEN
            intervalo_consulta := (NEW.hora_consulta - hora_anterior);
            SELECT intervalo_consulta >= intervalo_minimo INTO horario_valido;

            IF not horario_valido THEN
                raise ERROR_IN_ASSIGNMENT using
                message=FORMAT('O intervalo minimo entre duas consultas é de %1$s. ' ||
                               'A ultima consulta desse medico está marcada para %2$s h.', intervalo_minimo, hora_anterior);
            end if;

            intervalo_consulta := (proxima_hora - NEW.hora_consulta);
            SELECT intervalo_consulta >= intervalo_minimo INTO horario_valido;

            IF not horario_valido THEN
                raise ERROR_IN_ASSIGNMENT using
                message=FORMAT('O intervalo minimo entre duas consultas é de %1$s. ' ||
                               'A proxima consulta desse medico está marcada para %2$s h.', intervalo_minimo, proxima_hora);
            end if;

        ELSEIF proxima_hora IS NOT NULL AND hora_anterior IS NULL THEN
            intervalo_consulta := (proxima_hora - NEW.hora_consulta);
            SELECT intervalo_consulta >= intervalo_minimo INTO horario_valido;
            IF not horario_valido THEN
                raise ERROR_IN_ASSIGNMENT using
                message=FORMAT('O intervalo minimo entre duas consultas é de %1$s. ' ||
                               'A proxima consulta desse medico está marcada para %2$s h.', intervalo_minimo, proxima_hora);
            end if;
        end if;

        RETURN NEW;
    END;
$$;

alter function fc_trigger_consulta() owner to postgres;

