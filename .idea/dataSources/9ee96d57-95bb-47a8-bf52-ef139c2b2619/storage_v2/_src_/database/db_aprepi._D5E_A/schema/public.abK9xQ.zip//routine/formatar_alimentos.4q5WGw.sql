create function formatar_alimentos(alimentos json, id_alimento integer)
    returns TABLE(f_alimentos json, r text[])
    language plpgsql
as
$$
DECLARE
        nome_alimento varchar;
        grandeza_alimento int;
        uni_medida_alimento varchar;
        format_alimentos json := '{}';
        relatorio text[]:= '{"Novo recebimento de doação cadastrado com sucesso!"}';
    BEGIN
        FOR id_alimento, nome_alimento, grandeza_alimento, uni_medida_alimento IN
            SELECT cod_alimento, nome, grandeza, unidade_de_medida FROM ALIMENTO LOOP

            IF (alimentos->nome_alimento) IS NOT NULL THEN
                IF (alimentos->>nome_alimento)::int <= 0 THEN
                    RAISE RESTRICT_VIOLATION USING MESSAGE = 'Não pode haver alimentos com quantidade menor ou igual a zero.';
                END IF;
                relatorio := array_append(relatorio,
                    concat((alimentos->>nome_alimento)::int, ' x ', nome_alimento, ' ', grandeza_alimento, uni_medida_alimento));
                SELECT format_alimentos::jsonb ||
                       FORMAT(
                           '{"%1$s": {"%1$s": %2$s, "grandeza": %3$s, "unidade_de_medida": "%4$s"}}',
                           id_alimento, (alimentos->>nome_alimento)::int, grandeza_alimento, uni_medida_alimento)::jsonb INTO format_alimentos;
            END IF;
        END LOOP;

        RETURN QUERY SELECT format_alimentos, relatorio;
        RETURN;

        END;
$$;

alter function formatar_alimentos(json, integer) owner to postgres;

