create function inserir_item_cesta_basica(nome_alimento character varying, qtd integer)
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
        id_alimento int;
        alimento_cadastrado boolean := false;

    BEGIN
        id_alimento := buscar_cod_alimento(nome_alimento);
        SELECT EXISTS (SELECT * FROM cesta_basica WHERE cod_alimento = id_alimento) INTO alimento_cadastrado;
        IF alimento_cadastrado THEN
            UPDATE cesta_basica SET quantidade = qtd WHERE cod_alimento = id_alimento;
            RETURN QUERY SELECT FORMAT('Quantidade de %1$s na cesta basica atualizada para %2$s.', nome_alimento, qtd);
            RETURN;
        ELSE
            INSERT INTO cesta_basica(cod_alimento, quantidade) VALUES (id_alimento, qtd);
            RETURN QUERY SELECT FORMAT('%1$s inserido(a) na cesta basica com a quantidade %2$s.', nome_alimento, qtd);
            RETURN;
        end if;

        EXCEPTION
            WHEN ERROR_IN_ASSIGNMENT OR CASE_NOT_FOUND THEN
                RETURN QUERY SELECT SQLERRM;
            WHEN others THEN
                RETURN QUERY SELECT unnest(
                    ARRAY[CONCAT('Erro durante o cadastro -> ', SQLERRM)]);
    END;
$$;

alter function inserir_item_cesta_basica(varchar, integer) owner to postgres;

