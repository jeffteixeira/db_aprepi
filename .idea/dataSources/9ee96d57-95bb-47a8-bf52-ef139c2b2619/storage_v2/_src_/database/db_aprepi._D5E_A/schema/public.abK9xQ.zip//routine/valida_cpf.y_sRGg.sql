create function valida_cpf(value_cpf character varying) returns boolean
    language plpgsql
as
$$
DECLARE
        number char;
        first_number char;
        equals_numbers boolean := true;
        sanitize_cpf varchar;
        t int := 9;
        d int := 0;
        c int := 0;

    BEGIN
        sanitize_cpf := REGEXP_REPLACE(value_cpf, '([.-])+', '', 'g');

        if LENGTH(sanitize_cpf) != 11 THEN
            raise exception 'Diferente de 11 digitos: %', sanitize_cpf;
            raise notice 'Diferente de 11 digitos: %', sanitize_cpf;
            return false;
        END IF;

        first_number := SUBSTRING(sanitize_cpf, 1, 1);
        FOREACH number IN ARRAY regexp_split_to_array(sanitize_cpf, '') LOOP
            raise notice '===== foreach: %', number;
            IF number != first_number THEN
                equals_numbers := false;
                EXIT;
            end if;
        end loop;

        IF equals_numbers THEN
            raise notice 'Dentro dos invalidos: %', sanitize_cpf;
            RETURN false;
        end if;

        LOOP
            exit when t = 11;
--             raise notice 't(counter): % ', t;
            -- reinicia c contador c e o d
            c := 0;
            d := 0;
            LOOP
                exit when c = t;
                d := d + SUBSTRING(sanitize_cpf, c+1, 1)::int * ((t + 1) - c);
--                 raise notice 'd(incrmentado): % ', d;
--                 raise notice 'c(counter): % ', c;
                c := c + 1;
            end loop;

            d := ((10 * d) % 11) % 10;
--             raise notice 'c(aqui): % ', c;
--             raise notice 'string c: % ', SUBSTRING(sanitize_cpf, c+1, 1);
--             raise notice 'd var: % ', d;
            if (SUBSTRING(sanitize_cpf, c+1, 1)::int != d) THEN
--                 raise notice 'Deu erro no loop maix exterior: %', sanitize_cpf;
--                 raise notice 'c: % ', SUBSTRING(sanitize_cpf, c+1, 1);
--                 raise notice 'c: % ', SUBSTRING(sanitize_cpf, c, 1);
--                 raise notice 'd: % ', d;
                return false;
            END IF;
            t := t + 1;
        end loop;

        return true;
    END;
$$;

alter function valida_cpf(varchar) owner to postgres;

