create function buscar_cod_socio(cpf_socio character varying) returns integer
    language plpgsql
as
$$
DECLARE
        sanitize_cpf varchar := validador_cpf(cpf_socio);
        id int;
    BEGIN
        SELECT cod_socio INTO id FROM SOCIO WHERE cpf ilike sanitize_cpf;
        IF id IS NULL THEN
            RAISE CASE_NOT_FOUND USING MESSAGE = 'Nenhum socio encontrado com o CPF ' || cpf_socio;
        end if;
        RETURN id;
    END;
$$;

alter function buscar_cod_socio(varchar) owner to postgres;

