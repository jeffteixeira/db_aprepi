create function fc_trigger_socio() returns trigger
    language plpgsql
as
$$
BEGIN
        select validador_cpf(NEW.cpf) into NEW.cpf;
        raise notice 'new.cpf %', new.cpf;
        raise notice 'length(new.cpf) %', length(new.cpf);
        RETURN NEW;
    END;
$$;

alter function fc_trigger_socio() owner to postgres;

