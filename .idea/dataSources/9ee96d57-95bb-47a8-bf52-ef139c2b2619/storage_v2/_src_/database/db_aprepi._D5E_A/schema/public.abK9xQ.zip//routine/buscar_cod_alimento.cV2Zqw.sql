create function buscar_cod_alimento(nome_alimento character varying) returns integer
    language plpgsql
as
$$
DECLARE
        id int;
        total_rows int;
    BEGIN
        SELECT cod_alimento INTO id FROM ALIMENTO WHERE nome ilike nome_alimento;
        SELECT count(cod_alimento) INTO total_rows FROM ALIMENTO WHERE nome ilike nome_alimento;

        IF id is NULL OR total_rows = 0 THEN
            RAISE CASE_NOT_FOUND USING MESSAGE = 'Nenhum alimento encontrado com o nome ' || nome_alimento;
        ELSEIF total_rows > 1 THEN
            RAISE ERROR_IN_ASSIGNMENT USING MESSAGE = 'Mais de um alimento encontrado com o nome ' || nome_alimento
                                                    || '. Renomeie os alimentos que tem nomes iguais para nomes diferentes e tente novamente.';
        end if;
        RETURN id;
    END;
$$;

alter function buscar_cod_alimento(varchar) owner to postgres;

