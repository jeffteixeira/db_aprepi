create function buscar_cod_benfeitor(cpf_benfeitor character varying) returns integer
    language plpgsql
as
$$
DECLARE
        sanitize_cpf varchar := validador_cpf(cpf_benfeitor);
        id int;
    BEGIN
        SELECT cod_benfeitor INTO id FROM BENFEITOR WHERE cpf ilike sanitize_cpf;
        IF id IS NULL THEN
            RAISE CASE_NOT_FOUND USING MESSAGE = 'Nenhum benfeitor encontrado com o CPF ' || cpf_benfeitor;
        end if;
        raise notice '%', sanitize_cpf;
        RETURN id;
    END;
$$;

alter function buscar_cod_benfeitor(varchar) owner to postgres;

