create function buscar_cod_funcao(nome_funcao character varying) returns integer
    language plpgsql
as
$$
DECLARE
        id int;
        total_rows int;
    BEGIN
        SELECT cod_funcao INTO id FROM FUNCAO WHERE nome ilike nome_funcao;
        SELECT count(cod_funcao) INTO total_rows FROM FUNCAO WHERE nome ilike nome_funcao;

        IF id is NULL OR total_rows = 0 THEN
            RAISE CASE_NOT_FOUND USING MESSAGE = 'Nenhuma funcao encontrada com o nome ' || nome_funcao;
        ELSEIF total_rows > 1 THEN
            RAISE ERROR_IN_ASSIGNMENT USING MESSAGE = 'Mais de uma funcao encontrada com o nome ' || nome_funcao
                                                    || '. Renomeie as funcoes que tem nomes iguais para nomes diferentes e tente novamente.';
        end if;
        RETURN id;
    END;
$$;

alter function buscar_cod_funcao(varchar) owner to postgres;

