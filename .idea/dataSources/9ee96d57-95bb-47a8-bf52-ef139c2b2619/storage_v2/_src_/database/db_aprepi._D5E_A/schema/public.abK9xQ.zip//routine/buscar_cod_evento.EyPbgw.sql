create function buscar_cod_evento(nome_evento character varying) returns integer
    language plpgsql
as
$$
DECLARE
        id int;
        total_rows int;
    BEGIN
        SELECT cod_evento INTO id FROM EVENTO WHERE nome ilike nome_evento;
        SELECT count(cod_evento) INTO total_rows FROM EVENTO WHERE nome ilike nome_evento;

        IF id is NULL OR total_rows = 0 THEN
            RAISE CASE_NOT_FOUND USING MESSAGE = 'Nenhum evento encontrado com o nome ' || nome_evento;
        ELSEIF total_rows > 1 THEN
            RAISE ERROR_IN_ASSIGNMENT USING MESSAGE = 'Mais de um evento encontrado com o nome ' || nome_evento
                                                    || '. Renomeie os eventos que tem nomes iguais para nomes diferentes e tente novamente.';
        end if;
        RETURN id;
    END;
$$;

alter function buscar_cod_evento(varchar) owner to postgres;

