create function cadastrar_generico(nome_tabela character varying, campos json, forbidden_fields text[])
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
            required_fields text [];
            nullable_fields text [];
            campo text;
            erros text[]:= '{"OS SEGUINTES ERROS FORAM ENCONTRADOS"}';
            campos_validos boolean := true;
            keys_str text;
            keys text[];
            values_str text;
            values text[];
            insert_str text;
        BEGIN

            SELECT array_agg(column_name::TEXT) INTO required_fields
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE table_name ilike nome_tabela and is_nullable ilike 'NO' and
                  not column_name = ANY(forbidden_fields);

            FOREACH campo IN ARRAY required_fields LOOP
                IF (campos->campo) IS NULL THEN
                    raise notice '[%] nao pode ser vazio', campo;
                    erros := array_append(erros, concat('[', campo, '] não pode ser vazio'));
                    campos_validos := false;
                ELSE
                    keys := array_append(keys, campo);
                    values := array_append(values, (campos->campo)::text);
                end if;
            END LOOP;

            IF NOT campos_validos THEN
                RETURN QUERY SELECT nome FROM unnest(erros) as nome;
                RETURN;
            end if;

            SELECT array_agg(column_name::TEXT) INTO nullable_fields
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE table_name ilike nome_tabela and is_nullable ilike 'YES' and
                  not column_name = ANY(forbidden_fields);

            IF array_length(nullable_fields, 1) > 0 THEN
                FOREACH campo IN ARRAY nullable_fields LOOP
                    IF (campos->campo) IS NULL THEN
                        keys := array_append(keys, campo);
                        values := array_append(values, 'null');
                    ELSE
                        keys := array_append(keys, campo);
                        values := array_append(values, (campos->campo)::text);
                    end if;
                END LOOP;
            end if;

            keys_str := array_to_string(keys, ', ');
            values_str := array_to_string(values, ', ');

            insert_str := REGEXP_REPLACE(FORMAT('INSERT INTO %s(%s) VALUES (%s)',nome_tabela, keys_str, values_str), '"', '''', 'g');
            raise notice '%', insert_str;
            EXECUTE insert_str;

            RETURN QUERY SELECT unnest(ARRAY[FORMAT('Novo %s cadastrado com sucesso!', nome_tabela)]);

            EXCEPTION
            WHEN unique_violation THEN
                RETURN QUERY SELECT unnest(
                    ARRAY[CONCAT('Campo já cadastrado! ', SQLERRM)]);
            WHEN others THEN
                RETURN QUERY SELECT unnest(
                    ARRAY[CONCAT('Erro durante o cadastro -> ', SQLERRM)]);
        END;
$$;

alter function cadastrar_generico(varchar, json, text[]) owner to postgres;

