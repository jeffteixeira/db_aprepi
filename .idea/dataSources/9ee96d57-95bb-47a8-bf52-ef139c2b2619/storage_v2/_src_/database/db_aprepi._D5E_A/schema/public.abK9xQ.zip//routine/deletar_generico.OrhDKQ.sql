create function deletar_generico(nome_tabela character varying, chave character varying, valor character varying)
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
            qtd_r int;
            c_name varchar;
            c_values varchar;

            delete_str text;
        BEGIN

            SELECT cod_name, cod_value, qtd_registros into c_name, c_values, qtd_r from buscar_chave_valor(
                nome_tabela, chave, valor);


            delete_str := FORMAT('DELETE FROM %1$s WHERE %2$s IN %3$s', nome_tabela, c_name, c_values);
            raise notice '%', delete_str;
            EXECUTE delete_str;

            IF qtd_r = 1 THEN
                RETURN QUERY SELECT qtd_r || ' registro atualizado';
            ELSE
                RETURN QUERY SELECT qtd_r || ' registros atualizados';
            END IF;

            EXCEPTION
            WHEN CASE_NOT_FOUND OR ERROR_IN_ASSIGNMENT THEN
                RETURN QUERY SELECT unnest(ARRAY[SQLERRM]);
            WHEN others THEN
                RETURN QUERY SELECT unnest(
                    ARRAY[CONCAT('Erro durante a deleção -> ', SQLERRM)]);

        END;
$$;

alter function deletar_generico(varchar, varchar, varchar) owner to postgres;

