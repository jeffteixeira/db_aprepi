create function fc_trigger_alimento() returns trigger
    language plpgsql
as
$$
DECLARE
        unidades_de_medida varchar[] := '{"KG", "G", "ML", "L"}';
    BEGIN

        IF NEW.quantidade < 0 AND tg_op = 'INSERT' THEN
            raise ERROR_IN_ASSIGNMENT using
            message='Quantidade não pode ser negativo, insira uma quantidade maior ou igual a zero';
        ELSEIF NEW.quantidade < 0 THEN
            raise ERROR_IN_ASSIGNMENT using
            message=FORMAT('Estoque insulficiente de %1$s. Apenas %2$s disponiveis.', NEW.nome, OLD.quantidade);
        ELSEIF NOT NEW.unidade_de_medida ILIKE ANY(unidades_de_medida) THEN
            raise ERROR_IN_ASSIGNMENT using
            message='A unidade de medida precisa ser uma das seguintes: ' || array_to_string(unidades_de_medida, ',');
        end if;

        NEW.nome := btrim(NEW.nome);
        NEW.unidade_de_medida := upper(NEW.unidade_de_medida);

        RETURN NEW;
    END;
$$;

alter function fc_trigger_alimento() owner to postgres;

