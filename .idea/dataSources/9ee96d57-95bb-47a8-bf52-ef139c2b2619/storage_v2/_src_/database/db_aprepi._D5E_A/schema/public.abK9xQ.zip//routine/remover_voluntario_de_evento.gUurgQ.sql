create function remover_voluntario_de_evento(nome_evento character varying, cpf_voluntario character varying)
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
        id_evento int;
        id_voluntario int;
        nome_voluntario varchar;
        dt_fim_evento date;
    BEGIN
        id_evento := buscar_cod_evento(nome_evento);
        id_voluntario := buscar_cod_voluntario(cpf_voluntario);


        SELECT dt_fim INTO dt_fim_evento FROM evento WHERE cod_evento=id_evento;
        SELECT nome into nome_voluntario FROM voluntario WHERE cod_voluntario=id_voluntario;

        IF dt_fim_evento IS NOT NULL AND dt_fim_evento < current_date THEN
            RETURN QUERY SELECT 'Não é possivel remover um voluntário de um evento já encerrado.';
            RETURN;
        ELSEIF NOT EXISTS(SELECT FROM voluntario_funcao WHERE cod_evento=id_evento AND cod_voluntario=id_voluntario) THEN
            RETURN QUERY SELECT FORMAT('%1$s não está alocado no evento %2$s.', nome_voluntario, nome_evento);
            RETURN;
        end if;
        DELETE FROM voluntario_funcao WHERE cod_evento=id_evento and cod_voluntario=id_voluntario;
        RETURN QUERY SELECT FORMAT('%1$s removido do evento %2$s com sucesso.', nome_voluntario, nome_evento);

        EXCEPTION
        WHEN ERROR_IN_ASSIGNMENT OR CASE_NOT_FOUND THEN
            RETURN QUERY SELECT SQLERRM;
        WHEN others THEN
            RETURN QUERY SELECT CONCAT('Erro durante a remoção -> ', SQLERRM);
    END
$$;

alter function remover_voluntario_de_evento(varchar, varchar) owner to postgres;

