create function multi_cadastrar(nome_tabela character varying, array_json json)
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
        json_item json;
    BEGIN
        FOR json_item IN SELECT * FROM json_array_elements(array_json) LOOP
            RETURN QUERY SELECT cadastrar(nome_tabela, json_item);
        end loop;
        RETURN;
    END;
$$;

alter function multi_cadastrar(varchar, json) owner to postgres;

