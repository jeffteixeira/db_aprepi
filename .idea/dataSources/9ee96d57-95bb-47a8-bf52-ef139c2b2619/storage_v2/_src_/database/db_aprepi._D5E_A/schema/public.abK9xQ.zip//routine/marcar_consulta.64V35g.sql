create function marcar_consulta(nome_medico character varying, nome_especialidade character varying, cpf_socio character varying, data date, hora time without time zone)
    returns TABLE(n text)
    language plpgsql
as
$$
DECLARE
        id_socio int;
        id_medico int;
        id_especialidade int;
        id_medico_especialidade int;
    BEGIN
        id_socio := buscar_cod_socio(cpf_socio);
        id_medico := buscar_cod_medico(nome_medico);
        id_especialidade := buscar_cod_especialidade(nome_especialidade);

        SELECT cod_medico_especialidade INTO id_medico_especialidade FROM
        medico_especialidade WHERE cod_medico=id_medico AND cod_especialidade=id_especialidade;
        raise notice 'cod med: %', id_medico;
        raise notice 'cod esp: %', id_especialidade;
        raise notice 'cod med esp: %', id_medico_especialidade;

        IF id_medico_especialidade IS NULL THEN
            RETURN QUERY SELECT nome_medico || ' não atende na especialidade ' || nome_especialidade;
            RETURN;
        end if;

        INSERT INTO consulta(cod_socio, cod_medico_especialidade, dt_consulta, hora_consulta) VALUES
        (id_socio, id_medico_especialidade, data, hora);

        RETURN QUERY SELECT 'Consulta marcada com sucesso!';
        RETURN;

       EXCEPTION
        WHEN ERROR_IN_ASSIGNMENT OR CASE_NOT_FOUND THEN
            RETURN QUERY SELECT SQLERRM;
        WHEN others THEN
            RETURN QUERY SELECT 'Erro durante o cadastro da consulta -> ' || SQLERRM;
    END
$$;

alter function marcar_consulta(varchar, varchar, varchar, date, time) owner to postgres;

