create function deletar(nome_tabela character varying, chave character varying, valor character varying)
    returns TABLE(n text)
    security definer
    language plpgsql
as
$$
DECLARE
            forbidden_tables varchar[] := '{"consulta", ' ||
                                          '"recebimento", ' ||
                                          '"doacao", ' ||
                                          '"item_recebimento", ' ||
                                          '"item_doacao", ' ||
                                          '"medico_especialidade", ' ||
                                          '"voluntario_funcao", ' ||
                                          '"evento", ' ||
                                          '"cesta_basica", ' ||
                                          '"benfeitor_evento"}';
            table_exists boolean;
            nome_tabela_upper varchar := upper(nome_tabela);
        BEGIN
            SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name ilike nome_tabela) INTO table_exists;

            IF nome_tabela ILIKE ANY(forbidden_tables) THEN
                RETURN QUERY SELECT 'Essa tabela é controlada pelo sistema e não pode ser manipulada.';
                RETURN;
            ELSEIF NOT table_exists THEN
                RETURN QUERY SELECT unnest(
                    ARRAY[CONCAT('A tabela ', nome_tabela, ' não foi encontrada, verifique o nome e tente novamente.')]);
                    RETURN;
            END IF;

            -- SANITIZE DE CPF
            IF chave = 'cpf' THEN
                valor := validador_cpf(valor);
            end if;

            RETURN QUERY SELECT deletar_generico(nome_tabela_upper, chave, valor);
            RETURN;

            EXCEPTION
            WHEN ERROR_IN_ASSIGNMENT OR CASE_NOT_FOUND THEN
                RETURN QUERY SELECT SQLERRM;
            WHEN others THEN
                RETURN QUERY SELECT unnest(
                    ARRAY[CONCAT('Erro durante a delecao -> ', SQLERRM)]);
        END;
$$;

alter function deletar(varchar, varchar, varchar) owner to postgres;

