create function buscar_cod_voluntario(cpf_voluntario character varying) returns integer
    language plpgsql
as
$$
DECLARE
        sanitize_cpf varchar := validador_cpf(cpf_voluntario);
        id int;
    BEGIN
        SELECT cod_voluntario INTO id FROM VOLUNTARIO WHERE cpf ilike sanitize_cpf;
        IF id IS NULL THEN
            RAISE CASE_NOT_FOUND USING MESSAGE = 'Nenhum voluntario encontrado com o CPF ' || cpf_voluntario;
        end if;
        RETURN id;
    END
$$;

alter function buscar_cod_voluntario(varchar) owner to postgres;

